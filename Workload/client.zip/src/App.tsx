import React, { useState } from 'react';
import {
  Container,
  Paper,
  TextField,
  Button,
  Typography,
  Box,
  InputAdornment,
  IconButton,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Grid,
} from '@mui/material';
import { FolderOpen, CheckCircle, AlertTriangle, Info } from 'lucide-react';
import { migrateSQLtoLakehouse } from './util.ts'
declare global {
  interface Window {
    electron: {
      ipcRenderer: {
        invoke(channel: string, ...args: any[]): Promise<any>;
      };
    };
  }
}

function App() {
  const initialFormData = {
    workspaceId: '',
    lakehouseId: '',
    lakehouseName: '',
    sqlAnalyticsEndpointId: '',
    storedProcedureFolder: '',
    tablesFolder: '',
    viewsFolder: '',
    functionsFolder: '',
    outputFolder: ''
  };

  const [formData, setFormData] = useState(initialFormData);
  const [isMigrating, setIsMigrating] = useState<boolean>(false);
  const [successDialogOpen, setSuccessDialogOpen] = useState<boolean>(false);
  const [errorDialogOpen, setErrorDialogOpen] = useState<boolean>(false);
  const [sqlEndpointRequiredDialogOpen, setSqlEndpointRequiredDialogOpen] = useState<boolean>(false);
  const [formErrors, setFormErrors] = useState<{[key: string]: boolean}>({});
  const [missingFields, setMissingFields] = useState<string[]>([]);

  const fieldLabels: {[key: string]: string} = {
    workspaceId: 'Workspace ID',
    lakehouseId: 'Lakehouse ID',
    lakehouseName: 'Lakehouse Name',
    sqlAnalyticsEndpointId: 'SQL Analytics Endpoint ID'
  };

  const handleInputChange = (field: string) => (event: React.ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value;
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error for this field if value is not empty
    if (value.trim() !== '') {
      setFormErrors(prev => ({
        ...prev,
        [field]: false
      }));
    }
  };

  const handleFolderSelect = (field: string) => async () => {
    // Check if trying to access Views Folder without SQL Endpoint ID
    if (field === 'viewsFolder' && !formData.sqlAnalyticsEndpointId.trim()) {
      setSqlEndpointRequiredDialogOpen(true);
      return;
    }
    
    try {
      const selectedPath = await window.electron.ipcRenderer.invoke('select-folder');
      if (selectedPath) {
        setFormData(prev => ({
          ...prev,
          [field]: selectedPath
        }));
      }
    } catch (error) {
      console.error('Error selecting folder:', error);
    }
  };

  const resetForm = () => {
    setFormData(initialFormData);
    setFormErrors({});
  };

  const handleCloseSuccessDialog = () => {
    setSuccessDialogOpen(false);
  };

  const handleCloseErrorDialog = () => {
    setErrorDialogOpen(false);
  };

  const handleCloseSqlEndpointRequiredDialog = () => {
    setSqlEndpointRequiredDialogOpen(false);
  };

  const validateForm = () => {
    // Changed required fields to exclude sqlAnalyticsEndpointId
    const requiredFields = ['workspaceId', 'lakehouseId', 'lakehouseName'];
    const newErrors: {[key: string]: boolean} = {};
    const missing: string[] = [];
    let isValid = true;

    requiredFields.forEach(field => {
      if (!formData[field as keyof typeof formData]?.trim()) {
        newErrors[field] = true;
        missing.push(fieldLabels[field]);
        isValid = false;
      }
    });

    setFormErrors(newErrors);
    setMissingFields(missing);
    
    if (!isValid) {
      setErrorDialogOpen(true);
    }
    
    return isValid;
  };

  const handleSubmit = () => {
    if (!validateForm()) {
      return;
    }
    
    setIsMigrating(true);
    
    migrateSQLtoLakehouse(formData.workspaceId, formData.lakehouseId, formData.lakehouseName, formData.sqlAnalyticsEndpointId, formData.storedProcedureFolder, formData.functionsFolder, formData.tablesFolder, formData.viewsFolder, formData.outputFolder)
      .then(response => {
        console.log('Migration response:', response);
        // Show success dialog
        setSuccessDialogOpen(true);
        // Reset form
        resetForm();
      })
      .catch(error => {
        console.error('Error during migration:', error);
      })
      .finally(() => {
        setIsMigrating(false);
      });
  };

  // Check if SQL Endpoint ID is empty to disable Views Folder selection
  const isViewsFolderDisabled = !formData.sqlAnalyticsEndpointId.trim();

  return (
    <Container maxWidth="md" className="py-8">
      <Paper elevation={3} className="p-8">
        <Typography variant="h4" component="h1" gutterBottom className="text-center mb-8">
          SQL DB to Lakehouse Migration
        </Typography>

        <Box className="space-y-4">
          {/* Required Fields - Two columns */}
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Workspace ID"
                value={formData.workspaceId}
                onChange={handleInputChange('workspaceId')}
                variant="outlined"
                required
                error={formErrors.workspaceId}
                helperText={formErrors.workspaceId ? "Workspace ID is required" : ""}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Lakehouse ID"
                value={formData.lakehouseId}
                onChange={handleInputChange('lakehouseId')}
                variant="outlined"
                required
                error={formErrors.lakehouseId}
                helperText={formErrors.lakehouseId ? "Lakehouse ID is required" : ""}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Lakehouse Name"
                value={formData.lakehouseName}
                onChange={handleInputChange('lakehouseName')}
                variant="outlined"
                required
                error={formErrors.lakehouseName}
                helperText={formErrors.lakehouseName ? "Lakehouse Name is required" : ""}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="SQL Analytics Endpoint ID"
                value={formData.sqlAnalyticsEndpointId}
                onChange={handleInputChange('sqlAnalyticsEndpointId')}
                variant="outlined"
                error={formErrors.sqlAnalyticsEndpointId}
                helperText={formErrors.sqlAnalyticsEndpointId ? "SQL Analytics Endpoint ID is required for views migration" : "Required only for views migration"}
              />
            </Grid>
          </Grid>

          <Typography variant="h6" className="mt-6 mb-3">
            Folder Selections (Optional)
          </Typography>

          {/* Folder Selection Fields - Two columns */}
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Stored Procedure Folder"
                value={formData.storedProcedureFolder}
                onChange={handleInputChange('storedProcedureFolder')}
                variant="outlined"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={handleFolderSelect('storedProcedureFolder')}>
                        <FolderOpen size={20} />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Tables Folder"
                value={formData.tablesFolder}
                onChange={handleInputChange('tablesFolder')}
                variant="outlined"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={handleFolderSelect('tablesFolder')}>
                        <FolderOpen size={20} />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Views Folder"
                value={formData.viewsFolder}
                onChange={handleInputChange('viewsFolder')}
                variant="outlined"
                disabled={isViewsFolderDisabled}
                helperText={isViewsFolderDisabled ? "SQL Analytics Endpoint ID is required to select Views Folder" : ""}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={handleFolderSelect('viewsFolder')} disabled={isViewsFolderDisabled}>
                        <FolderOpen size={20} />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Functions Folder"
                value={formData.functionsFolder}
                onChange={handleInputChange('functionsFolder')}
                variant="outlined"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={handleFolderSelect('functionsFolder')}>
                        <FolderOpen size={20} />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Output Folder"
                value={formData.outputFolder}
                onChange={handleInputChange('outputFolder')}
                variant="outlined"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={handleFolderSelect('outputFolder')}>
                        <FolderOpen size={20} />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
          </Grid>

          <Box className="mt-6">
            {isMigrating && (
              <Box className="mb-4 flex flex-col items-center">
                <CircularProgress 
                  size={60} 
                  thickness={4}
                  className="mb-2"
                />
                <Typography variant="body1">
                  Migration in Process
                </Typography>
              </Box>
            )}

            <Button
              variant="contained"
              color="primary"
              fullWidth
              size="large"
              onClick={handleSubmit}
              disabled={isMigrating}
              startIcon={isMigrating ? <CircularProgress size={20} color="inherit" /> : null}
            >
              {isMigrating ? 'Migrating...' : 'Start Migration'}
            </Button>
          </Box>
        </Box>
      </Paper>

      {/* Success Dialog */}
      <Dialog
        open={successDialogOpen}
        onClose={handleCloseSuccessDialog}
        aria-labelledby="success-dialog-title"
        aria-describedby="success-dialog-description"
      >
        <DialogTitle id="success-dialog-title" className="flex items-center">
          <CheckCircle className="text-green-500 mr-2" size={24} />
          Migration Successful
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="success-dialog-description">
            Migration Successful, Created Migration Logs Successfully
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseSuccessDialog} color="primary" autoFocus>
            Close
          </Button>
        </DialogActions>
      </Dialog>

      {/* Error Dialog for Missing Fields */}
      <Dialog
        open={errorDialogOpen}
        onClose={handleCloseErrorDialog}
        aria-labelledby="error-dialog-title"
        aria-describedby="error-dialog-description"
      >
        <DialogTitle id="error-dialog-title" className="flex items-center text-red-500">
          <AlertTriangle className="text-red-500 mr-2" size={24} />
          Missing Required Fields
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="error-dialog-description" className="mb-2">
            Please fill in the following required fields before starting migration:
          </DialogContentText>
          <List dense>
            {missingFields.map((field, index) => (
              <ListItem key={index}>
                <ListItemIcon className="min-w-8">
                  <div className="h-2 w-2 rounded-full bg-red-500"></div>
                </ListItemIcon>
                <ListItemText primary={field} />
              </ListItem>
            ))}
          </List>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseErrorDialog} color="primary" autoFocus>
            OK
          </Button>
        </DialogActions>
      </Dialog>

      {/* SQL Endpoint Required Dialog */}
      <Dialog
        open={sqlEndpointRequiredDialogOpen}
        onClose={handleCloseSqlEndpointRequiredDialog}
        aria-labelledby="sql-endpoint-dialog-title"
        aria-describedby="sql-endpoint-dialog-description"
      >
        <DialogTitle id="sql-endpoint-dialog-title" className="flex items-center">
          <Info className="text-blue-500 mr-2" size={24} />
          SQL Analytics Endpoint Required
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="sql-endpoint-dialog-description">
            Please enter a SQL Analytics Endpoint ID first before selecting a Views Folder.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseSqlEndpointRequiredDialog} color="primary" autoFocus>
            OK
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}

export default App;