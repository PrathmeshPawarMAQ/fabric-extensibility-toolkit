export async function migrateSQLtoLakehouse(workspaceID: string, lakehouseId: string, lakehouseName: string, sqlEndpointID: string, sp_folder_path: string, function_folder_path: string, tables_folder_path: string, views_folder_path: string, output_folder_path: string): Promise<string> {
  
    const formData = new FormData();
    formData.append("workspace_id", workspaceID);
    formData.append("lakehouse_id", lakehouseId);
    formData.append("lakehouse_name", lakehouseName);
    formData.append("sql_endpoint_id", sqlEndpointID);
    formData.append("views_folder_path", views_folder_path);
    formData.append("sp_folder_path", sp_folder_path);
    formData.append("functions_folder_path", function_folder_path);
    formData.append("tables_folder_path", tables_folder_path);
    formData.append("output_folder_path", output_folder_path);
  
    const response = await fetch("http://127.0.0.1:8000/migrate", {
      method: "POST",
      body: formData,
    });
    console.log(response)
    if (!response.ok) {
      throw new Error("Failed to migrate SQL to Lakehouse");
    }
    console.log(response)
    return response.json();
  }