import re
import os
import json

def create_scripts_dictionary(folder_path):
    """
    Create a dictionary of function names and their corresponding script contents.
    
    Args:
        folder_path (str): Path to the folder containing function script files
    
    Returns:
        dict: A dictionary where keys are function names and values are script contents
    """
    scripts = {}
    
    for filename in os.listdir(folder_path):
        if filename.endswith('.sql'):
            file_path = os.path.join(folder_path, filename)
            name = os.path.splitext(filename)[0]
            
            with open(file_path, 'r') as file:
                script_content = file.read()
            scripts[name] = script_content
    
    return scripts

def detect_udf_in_stored_procedure(sp_code):
    """
    Detects if user-defined functions are used in a stored procedure.
    
    Args:
        sp_code (str): The SQL stored procedure code
        
    Returns:
        bool: True if user-defined functions are detected, False otherwise
    """

    udf_patterns = [
        r'CREATE\s+FUNCTION',
        r'ALTER\s+FUNCTION',
        r'EXEC\s+(\w+\.)*\w+',
        r'dbo\.\w+\s*\(',
        r'CROSS\s+APPLY\s+(\w+\.)*\w+',
        r'OUTER\s+APPLY\s+(\w+\.)*\w+'
    ]
    
    for pattern in udf_patterns:
        if re.search(pattern, sp_code, re.IGNORECASE):
            return True
    
    return False

def detect_complex_types_in_table(table_def):
    """
    Detects complex data types in SQL table definition.
    
    Args:
        table_def (str): SQL table definition script
    
    Returns:
        dict: Dictionary containing complex type columns and their original types
    """
    complex_types = [
        r'json', r'jsonb', r'xml', r'binary', r'varbinary', r'image', 
        r'geometry', r'geography', r'hierarchyid', r'spatial', r'variant', 
        r'array', r'struct', r'map', r'hstore', r'blob', r'clob', r'nclob',
        r'object', r'nested', r'complex'
    ]
    
    column_pattern = r'(?i)(\w+)\s+((?:\w+\s*(?:\(\s*\d+(?:\s*,\s*\d+)?\s*\))?)+)(?:\s+not\s+null|\s+null)?'
    columns = re.findall(column_pattern, table_def)
    
    complex_columns = {}
    
    for column_name, data_type in columns:
        data_type = data_type.strip().lower()
        for complex_type in complex_types:
            if re.search(rf'\b{complex_type}\b', data_type):
                complex_columns[column_name] = data_type
                break
    
    return complex_columns

def create_notebook_from_code(code_string, lakehouse_id, lakehouse_name, workspace_id, output_file="output_notebook.ipynb"):
    """Creates a Jupyter notebook from code with cell separators."""
    code_string = code_string.replace('```python\n', '').replace('\n```', '')
    code_string = code_string.replace('\r', '')  
    cell_pattern = r"# Cell-+"
    code_cells = re.split(cell_pattern, code_string)
    code_cells = [cell.strip() for cell in code_cells if cell.strip()]
    
    notebook = {
        "cells": [],
        "metadata": {
            "kernelspec": {"display_name": "PySpark", "language": "python", "name": "synapse_pyspark"},
            "language_info": {"name": "python", "version": "3.8.0"},
            "dependencies": {
                "lakehouse": {
                  "default_lakehouse": f"{lakehouse_id}",
                  "default_lakehouse_name": f"{lakehouse_name}",
                  "default_lakehouse_workspace_id": f"{workspace_id}",
                  "known_lakehouses": [
                    {
                      "id": f"{lakehouse_id}"
                    }
                  ]
                }
              }
        },
        "nbformat": 4,
        "nbformat_minor": 4
    }
    
    first_cell = code_cells[0]
    first_markdown_cell = {
        "cell_type": "markdown",
        "metadata": {},
        "source": [line + "\n" for line in first_cell.splitlines()],
        "execution_count": None,
        "outputs": []
    }
    notebook["cells"].append(first_markdown_cell)
    
    for cell_content in code_cells[1:]:
        lines = [line + "\n" for line in cell_content.splitlines()]
        notebook["cells"].append({
            "cell_type": "code",
            "metadata": {},
            "source": lines,
            "execution_count": None,
            "outputs": []
        })
    
    with open(output_file, 'w') as f:
        json.dump(notebook, f, indent=2)
    
    print(f"Notebook successfully created at: {os.path.abspath(output_file)}")

def extract_code_from_agent_output(agent_output):
    """
    Extracts the code blocks from the AI agent output and reconstructs them properly,
    removing any Python code block markers.
    
    Args:
        agent_output (str): The raw output from the AI agent
        
    Returns:
        str: The extracted code with cell separators
    """
    
    lines = agent_output.split('\n')
    code_content = []
    capture = False
    
    for line in lines:
        if "# Cell------------------------" in line:
            code_content.append(line)
            capture = True
        elif capture:
            code_content.append(line)
    
    return '\n'.join(code_content)