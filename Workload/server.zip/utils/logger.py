import os
from datetime import datetime
# import sempy_labs as labs
# from uuid import UUID
# from sempy_labs import ConnectLakehouse
from utils.helpers import create_scripts_dictionary, detect_udf_in_stored_procedure, detect_complex_types_in_table, create_notebook_from_code
from services.sp_to_pyspark import StoredProcedureToSQL
from services.functions_to_pyspark import SQLUDFToPySparkConverter
from services.create_tables_in_lakehouse import TableCreationConverter

def create_output_log_file(log_type):
    """
    Create a directory for migration logs and generate a unique filename.
    
    :param log_type: Type of log (e.g., 'Migration')
    :return: Full path to the log file
    """
    logs_dir = 'Logs'
    os.makedirs(logs_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = os.path.join(logs_dir, f'{log_type}_Log_{timestamp}.txt')
    return log_filename

def log_sp_migration(sp_folder_path, workspace_id, lakehouse_id, lakehouse_name, log_file, output_folder_path):
    """
    Logs the stored procedure conversion process, including UDF detection.

    Args:
        sp_folder_path (str): Path to folder containing stored procedure SQL files
        workspace_id (str): Microsoft Fabric workspace ID
        lakehouse_id (str): Microsoft Fabric lakehouse ID
        lakehouse_name (str): Name of the lakehouse
        log_file (str): Path to the log file
        output_folder_path (str): Path to the output folder

    Returns:
        str: Path to the log file
    """
    with open(log_file, 'a') as log_writer:
        log_writer.write("=" * 50 + "\n")
        log_writer.write("STORED PROCEDURES MIGRATION\n")
        log_writer.write("=" * 50 + "\n\n")

        sp_dict = create_scripts_dictionary(sp_folder_path)
        for sp_name, sp_code in sp_dict.items():
            contains_udf = detect_udf_in_stored_procedure(sp_code)

            try:
                converter = StoredProcedureToSQL()
                result = converter.convert_stored_procedure(
                    stored_procedure=sp_code,
                    workspace_id=workspace_id, 
                    lakehouse_id=lakehouse_id
                )
                agent_code = result.raw
                notebook_path = f'{output_folder_path}/SP_{sp_name}.ipynb'

                create_notebook_from_code(
                    agent_code, 
                    lakehouse_id, 
                    lakehouse_name, 
                    workspace_id, 
                    notebook_path
                )

                log_writer.write(f"SP Name: {sp_name}\n")
                log_writer.write(f"Local Path of SP: {os.path.join(sp_folder_path, f'{sp_name}.sql')}\n")
                log_writer.write(f"Local Path to Notebook Created: {notebook_path}\n")
                log_writer.write(f"Workspace ID: {workspace_id}\n")
                log_writer.write(f"Lakehouse ID: {lakehouse_id}\n")
                log_writer.write(f"Lakehouse Name: {lakehouse_name}\n")

                if contains_udf:
                    log_writer.write("Next Steps: Update Required\n")
                    log_writer.write("Reason: User Defined Functions Used\n")
                else:
                    log_writer.write("Next Steps: Review Required\n")
                    log_writer.write("Reason: AI-generated Code\n")

            except Exception as e:
                log_writer.write(f"SP Name: {sp_name}\n")
                log_writer.write(f"Local Path of SP: {os.path.join(sp_folder_path, f'{sp_name}.sql')}\n")
                log_writer.write(f"ERROR: Conversion failed - {str(e)}\n")
                log_writer.write("Next Steps: Manual Conversion Required\n")
                log_writer.write("Reason: Conversion Error\n")

            log_writer.write("-" * 50 + "\n\n")

    return log_file

def log_view_creation(views_folder_path, workspace_id, lakehouse_id, lakehouse_name, sql_endpoint_id, log_file):
    """
    Logs the view creation process, including UDF detection.
    
    Args:
        views_folder_path (str): Path to folder containing view SQL files
        workspace_id (str): Microsoft Fabric workspace ID
        lakehouse_id (str): Microsoft Fabric lakehouse ID
        lakehouse_name (str): Name of the lakehouse
        sql_endpoint_id (str): SQL Analytics endpoint ID
        log_file (str): Path to the log file to append to
    
    Returns:
        str: Path to the log file
    """
    with open(log_file, 'a') as log_writer:
        log_writer.write("=" * 50 + "\n")
        log_writer.write("VIEWS MIGRATION\n")
        log_writer.write("=" * 50 + "\n\n")
        # connection = ConnectLakehouse(lakehouse=lakehouse_id, workspace=workspace_id, timeout=30)
        view_scripts_dict = create_scripts_dictionary(views_folder_path)
        for view_name, script_content in view_scripts_dict.items():
            # results = connection.query(script_content)
            sql_endpoint_link = f"https://app.fabric.microsoft.com/groups/{workspace_id}/lakewarehouses/{sql_endpoint_id}?experience=fabric-developer"
            
            log_writer.write(f"View Name: {view_name}\n")
            log_writer.write(f"Local Path to View: {os.path.join(views_folder_path, f'{view_name}.sql')}\n")
            log_writer.write(f"SQL Analytics Endpoint: {lakehouse_name}\n")
            log_writer.write(f"Workspace ID: {workspace_id}\n")
            log_writer.write(f"SQL Endpoint Link: {sql_endpoint_link}\n")
            log_writer.write("Next Steps: Review Required\n")
            log_writer.write("Reason: Query integrity and data validation needed to be checked\n")
            log_writer.write("-" * 50 + "\n\n")
    
    return log_file

def log_function_migration(functions_folder_path, log_file, output_folder_path):
    """
    Logs the function creation process and writes PySpark code to .py files.
    
    Args:
        functions_folder_path (str): Path to folder containing function SQL files
        log_file (str): Path to the log file to append to
    
    Returns:
        str: Path to the log file
    """
    
    with open(log_file, 'a') as log_writer:
        log_writer.write("=" * 50 + "\n")
        log_writer.write("USER DEFINED FUNCTIONS MIGRATION\n")
        log_writer.write("=" * 50 + "\n\n")
        udf_dict = create_scripts_dictionary(functions_folder_path)
        for udf_name, udf_code in udf_dict.items():
            try:
                converter = SQLUDFToPySparkConverter()
                result = converter.convert_udf(
                    sql_udf=udf_code
                )
                agent_code = result.raw
                agent_code = agent_code.replace('python```', '')
                agent_code = agent_code.replace('```', '')
                py_file_path = f'{output_folder_path}/Function_{udf_name}.py'
                with open(py_file_path, 'w') as py_file:
                    py_file.write(agent_code)
                
                log_writer.write(f"UDF Name: {udf_name}\n")
                log_writer.write(f"Local Path of UDF: {os.path.join(functions_folder_path, f'{udf_name}.sql')}\n")
                log_writer.write(f"Python File Created: {py_file_path}\n")
                log_writer.write("Next Steps: Update Required\n")
                log_writer.write("Reason: UDF code written to Python file, need to create a .whl file to import as a custom package\n")
            except Exception as e:
                log_writer.write(f"UDF Name: {udf_name}\n")
                log_writer.write(f"Local Path of UDF: {os.path.join(functions_folder_path, f'{udf_name}.sql')}\n")
                log_writer.write(f"ERROR: Conversion failed - {str(e)}\n")
                log_writer.write("Next Steps: Manual Conversion Required\n")
                log_writer.write("Reason: Conversion Error\n")
            log_writer.write("-" * 50 + "\n\n")
    return log_file

def log_table_creation(table_folder_path, workspace_id, lakehouse_id, lakehouse_name, log_file, output_folder_path):
    """
    Logs the table creation process.
    
    Args:
        table_folder_path (str): Path to folder containing table definition files
        workspace_id (str): Microsoft Fabric workspace ID
        lakehouse_id (str): Microsoft Fabric lakehouse ID
        lakehouse_name (str): Name of the lakehouse
        log_file (str): Path to the log file
    
    Returns:
        str: Path to the log file
    """
    with open(log_file, 'a') as log_writer:
        log_writer.write("=" * 50 + "\n")
        log_writer.write("TABLE CREATION\n")
        log_writer.write("=" * 50 + "\n\n")
        
        table_definition_dict = create_scripts_dictionary(table_folder_path)
        for table_name, table_def in table_definition_dict.items():
            contains_complex_types = detect_complex_types_in_table(table_def)
            
            try:
                converter = TableCreationConverter()
                result = converter.convert_table_definition(
                    table_creation_script=table_def,
                    workspace_id=workspace_id, 
                    lakehouse_id=lakehouse_id,
                    lakehouse_name=lakehouse_name
                )
                sql_code = result.raw
                notebook_path = f'{output_folder_path}/Table_{table_name}.ipynb'
                
                create_notebook_from_code(
                    sql_code, 
                    lakehouse_id, 
                    lakehouse_name, 
                    workspace_id, 
                    notebook_path
                )
                
                log_writer.write(f"Table Name: {table_name}\n")
                log_writer.write(f"Local Path of Table Definition: {os.path.join(table_folder_path, f'{table_name}.sql')}\n")
                log_writer.write(f"Local Path to Notebook Created: {notebook_path}\n")
                log_writer.write(f"Workspace ID: {workspace_id}\n")
                log_writer.write(f"Lakehouse ID: {lakehouse_id}\n")
                log_writer.write(f"Lakehouse Name: {lakehouse_name}\n")
                
                if contains_complex_types:
                    log_writer.write("Next Steps: Update Required\n")
                    log_writer.write("Reason: Complex Data Types Used\n")
                else:
                    log_writer.write("Next Steps: Review Required\n")
                    log_writer.write("Reason: AI-generated Code\n")
            
            except Exception as e:
                log_writer.write(f"Table Name: {table_name}\n")
                log_writer.write(f"Local Path of Table Definition: {os.path.join(table_folder_path, f'{table_name}.sql')}\n")
                log_writer.write(f"ERROR: Creation failed - {str(e)}\n")
                log_writer.write("Next Steps: Manual Creation Required\n")
                log_writer.write("Reason: Conversion Error\n")
                
            log_writer.write("-" * 50 + "\n\n")
            
    return log_file

def log_migration(sp_folder_path, views_folder_path, tables_folder_path, functions_folder_path, workspace_id, lakehouse_id, lakehouse_name, output_folder_path, sql_endpoint_id):
    """
    Create a comprehensive migration log file with separate sections for SPs, Views, Tables, and Functions.
    
    Args:
        sp_folder_path (str): Path to stored procedures folder
        views_folder_path (str): Path to views folder
        tables_folder_path (str): Path to tables folder
        functions_folder_path (str): Path to functions folder
        workspace_id (str): Fabric workspace ID
        lakehouse_id (str): Lakehouse ID
        lakehouse_name (str): Lakehouse name
        sql_endpoint_id (str): SQL Analytics endpoint ID
    
    Returns:
        str: Path to the created log file
    """
    log_file = create_output_log_file('Migration')
    
    with open(log_file, 'w') as log_writer:
        log_writer.write("=" * 50 + "\n")
        log_writer.write("MICROSOFT FABRIC MIGRATION LOG\n")
        log_writer.write(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        log_writer.write("=" * 50 + "\n\n")
    
    if os.path.exists(tables_folder_path):
        log_file = log_table_creation(tables_folder_path, workspace_id, lakehouse_id, lakehouse_name, log_file, output_folder_path)

    if os.path.exists(sp_folder_path):
        log_file = log_sp_migration(sp_folder_path, workspace_id, lakehouse_id, lakehouse_name, log_file, output_folder_path)
    
    if os.path.exists(views_folder_path):
        log_file = log_view_creation(views_folder_path, workspace_id, lakehouse_id, lakehouse_name, sql_endpoint_id, log_file)
    
    if os.path.exists(functions_folder_path):
        log_file = log_function_migration(functions_folder_path, log_file, output_folder_path)
    
    with open(log_file, 'a') as log_writer:
        log_writer.write("=" * 50 + "\n")
        log_writer.write("MIGRATION SUMMARY\n")
        log_writer.write("=" * 50 + "\n\n")
        log_writer.write("Migration process completed.\n")
        log_writer.write(f"Log file location: {log_file}\n")
        log_writer.write(f"Migration completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
    
    print(f"Migration log created at: {log_file}")
    return log_file