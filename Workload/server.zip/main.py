from typing import Annotated
from fastapi import FastAPI, Form
from services.migration_runner import run_migration
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/migrate")
def migrate(
    workspace_id: Annotated[str, Form()],
    lakehouse_id: Annotated[str, Form()],
    lakehouse_name: Annotated[str, Form()],
    sql_endpoint_id: Annotated[str, Form()],
    views_folder_path: Annotated[str, Form()],
    sp_folder_path: Annotated[str, Form()],
    functions_folder_path: Annotated[str, Form()],
    tables_folder_path: Annotated[str, Form()],
    output_folder_path: Annotated[str, Form()]
):
    config = {
        "workspace_id": workspace_id,
        "lakehouse_id": lakehouse_id,
        "lakehouse_name": lakehouse_name,
        "sql_endpoint_id": sql_endpoint_id,
        "views_folder_path": views_folder_path,
        "sp_folder_path": sp_folder_path,
        "functions_folder_path": functions_folder_path,
        "tables_folder_path": tables_folder_path,
        "output_folder_path": output_folder_path
    }
    run_migration(config)
    return {"status": "Migration started", "message": "Check output folder for results."}

app.mount("/", StaticFiles(directory="../client/dist", html=True))