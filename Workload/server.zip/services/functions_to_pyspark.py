from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM

class SQLUDFToPySparkConverter:
    """
    A specialized system for converting SQL user-defined functions to optimized PySpark code.
    """
    
    def __init__(self):
        """Initialize the SQLUDFToPySparkConverter with necessary configurations."""
        load_dotenv()
        self.llm = LLM(
            model="azure/gpt-4o", 
            temperature=0
        )
        
    def create_agents(self):
        """Create and return specialized agents for the SQL UDF to PySpark conversion pipeline."""
        udf_analyzer = Agent(
            role="SQL UDF Analyst",
            goal="Extract complete logic and purpose from SQL user-defined functions",
            backstory="You are a database expert specializing in decoding complex SQL functions across all SQL dialects. You excel at identifying core algorithms and data flow patterns.",
            verbose=True,
            llm=self.llm,
        )
        
        pyspark_coder = Agent(
            role="PySpark Translation Specialist",
            goal="Transform SQL logic into idiomatic and optimized PySpark code",
            backstory="You're a PySpark expert who translates SQL operations into efficient DataFrame APIs. You understand nuances of both systems and produce clean, performant code that handles SQL's implicit behaviors explicitly in PySpark.",
            verbose=True,
            llm=self.llm,
        )
        
        code_optimizer = Agent(
            role="Code Integration & Optimization Expert",
            goal="Integrate, optimize and finalize production-quality PySpark code",
            backstory="You're a software engineer who specializes in code quality and performance optimization. You ensure proper structure, eliminate inefficiencies, and produce maintainable code that follows all best practices for PySpark applications.",
            verbose=True,
            llm=self.llm,
        )
        
        return [udf_analyzer, pyspark_coder, code_optimizer]
    
    def create_tasks(self, agents):
        """Create sequenced tasks with clear instructions for the conversion pipeline."""
        analyze_udf_task = Task(
            description="""
            Perform comprehensive analysis of the SQL UDF {sql_udf} to extract:
            
            1. FUNCTION PURPOSE: What business logic or data transformation does this UDF perform?
            2. EXECUTION FLOW: What are the key processing steps and their sequence?
            3. CRITICAL SQL FEATURES: Identify any SQL-specific operations that need special handling in PySpark
            4. FUNCTION PARAMETERS AND RETURN VALUES: Understand the input/output contract
            """,
            expected_output="""
            Provide a structured analysis with these sections:
            
            1. UDF PURPOSE: Clear explanation of what the function does and why
            2. EXECUTION FLOW: Step-by-step breakdown of the logic
            3. PYSPARK CONVERSION CHALLENGES: Specific SQL features needing attention
            4. INPUT/OUTPUT CONTRACT: Parameters, types, and return structure
            """,
            agent=agents[0],
        )
        
        convert_to_pyspark_task = Task(
            description="""
            Convert the SQL UDF {sql_udf} to equivalent PySpark code:
            
            1. Translate SQL operations to appropriate DataFrame methods and expressions
            2. Address these common SQL-to-PySpark conversion challenges:
               - Handle column name ambiguities in joins with explicit qualification
               - Convert SQL window functions to PySpark window functions
               - Transform SQL aggregations to their PySpark equivalents
               - Replace SQL string manipulations with PySpark string functions
               - Convert date/time operations to appropriate PySpark functions
            """,
            expected_output="""
            Produce clean PySpark transformation code that:
            
            1. Uses only DataFrame operations (no Spark SQL unless absolutely necessary)
            2. Includes all necessary imports at the top
            3. Has clear commenting for complex operations
            4. Follows PySpark functional transformation style 
            5. Preserves the original function signature with appropriate adjustments for PySpark
            """,
            agent=agents[1],
            context=[analyze_udf_task],
        )
        
        integrate_and_optimize_task = Task(
            description="""
            Create a production-ready PySpark function by integrating and optimizing all components:
            
            1. Structure the code with proper sections:
               - Imports
               - Function signature matching original UDF params
               - Transformation logic
               - Return statement
            
            2. Apply these optimization and quality standards:
               - Use consistent snake_case naming
               - Eliminate redundant operations
               - Add clear docstrings and inline comments
               - Include disclaimer header about AI-generated code
            """,
            expected_output="""
            ONLY the complete, final, production-ready PySpark code with no explanations or additional text.
            """,
            agent=agents[2],
            context=[analyze_udf_task, convert_to_pyspark_task],
        )
        
        return [
            analyze_udf_task,
            convert_to_pyspark_task,
            integrate_and_optimize_task,
        ]
    
    def create_crew(self):
        """Creates the SQLUDFToPySparkConverter crew with all agents and tasks."""
        agents = self.create_agents()
        tasks = self.create_tasks(agents)
        return Crew(
            agents=agents,
            tasks=tasks,
            process=Process.sequential,
            verbose=True,
        )
    
    def convert_udf(self, sql_udf, workspace_id=None, lakehouse_id=None):
        """
        Execute the end-to-end conversion process for a SQL UDF to PySpark.
        
        Args:
            sql_udf (str): The SQL User-Defined Function to convert
            workspace_id (str, optional): The Microsoft Fabric workspace ID (kept for backwards compatibility)
            lakehouse_id (str, optional): The Microsoft Fabric Lakehouse ID (kept for backwards compatibility)
            
        Returns:
            dict: Results from the crew execution with the final PySpark code
        """
        if not sql_udf:
            raise ValueError("sql_udf must be provided")
        
        inputs = {
            "sql_udf": sql_udf
        }
            
        crew = self.create_crew()
        result = crew.kickoff(inputs=inputs)
        
        return result