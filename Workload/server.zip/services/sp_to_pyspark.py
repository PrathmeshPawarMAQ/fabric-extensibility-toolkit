from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM
class StoredProcedureToSQL:
    """StoredProcedureToSQL class for converting SQL stored procedures to PySpark code 
    with automatic table reading from Microsoft Fabric Lakehouse."""
    
    def __init__(self):
        """
        Initialize the StoredProcedureToSQL class.
        """
        load_dotenv()
        self.llm = LLM(
            model="azure/gpt-4o", 
            temperature=0
        )
        
    def create_agents(self):
        """Create and return the agents for the SQL to PySpark conversion process."""
        sql_analyzer_agent = Agent(
            role="SQL Stored Procedure Analyzer",
            goal="Analyze the core implementation and logic used in the stored procedure",
            backstory="An expert SQL Analyzer with deep understanding of all SQL platforms who identifies key operations, data transformations, and business logic in stored procedures.",
            verbose=True,
            llm=self.llm,
        )
        
        code_converter_agent = Agent(
            role="SQL to PySpark Converter",
            goal="Convert SQL to PySpark with automatic table extraction and reading",
            backstory="An expert who transforms complex SQL logic into efficient PySpark implementations, automatically identifies all tables referenced, and ensures they are properly read from Fabric Lakehouse paths before operations are performed.",
            verbose=True,
            llm=self.llm,
        )
        
        code_standards_checking_agent = Agent(
            role="PySpark Code Standards Reviewer",
            goal="Ensure the converted PySpark code follows best practices and coding standards",
            backstory="An expert PySpark code reviewer who validates code against standards including: 1. snake_case for variable names, 2. proper documentation, 3. removal of unused imports/variables, 4. PySpark-specific optimizations.",
            verbose=True,
            llm=self.llm,
        )
        
        return [
            sql_analyzer_agent,
            code_converter_agent,
            code_standards_checking_agent
        ]
    
    def create_tasks(self, agents):
        """Create and return the tasks for the SQL to PySpark conversion process."""
        stored_procedure_analysis_task = Task(
            description="""
            Thoroughly analyze the SQL stored procedure {stored_procedure} to:
            1. Understand its core logic and data flows
            2. Identify key SQL operations and potential conversion challenges
            3. Outline the business logic and purpose of the procedure
            """,
            expected_output="""
            A detailed analysis including:
            1. Overview of what the procedure does
            2. Key SQL operations and their purposes
            3. Data flows and business logic
            4. Potential conversion challenges
            """,
            agent=agents[0],
        )
        
        conversion_task = Task(
            description="""
            Convert the SQL stored procedure {stored_procedure} into equivalent, optimized PySpark code with automatic table extraction and reading.
            
            You must:
            1. Automatically identify ALL tables referenced in the stored procedure (FROM clauses, JOINs, subqueries, CTEs, etc.)
            
            2. For each table, add code to read it from the Lakehouse at the beginning using:
               abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}/Tables/schema/table_name
               where workspace_id is {workspace_id}, lakehouse_id is {lakehouse_id}, table name should be all lowercased (no extra underscores are added, just lowercase) and if no schema is present consider default schema as 'dbo'.
            
            3. Implement the full stored procedure logic using PySpark operations
            """,
            expected_output="""
            Complete, integrated PySpark code that:
            1. Automatically detects and reads all required tables from the Lakehouse at the beginning
            2. Implements the stored procedure logic using the loaded DataFrames
            3. Uses appropriate DataFrame operations instead of SQL operations
            4. Includes comments explaining complex operations
            """,
            agent=agents[1],
            context=[stored_procedure_analysis_task],
        )
        
        code_standards_review_task = Task(
            description="""
            Review and refine the integrated PySpark code for:
            1. Adherence to coding standards (snake_case naming, proper documentation)
            2. Removal of unused imports/variables
            3. PySpark-specific optimizations
            4. Correct table reading from the Lakehouse paths
            5. Divide the entire code into appropriate cells and add a comment line "Cell------------------------" before each cell in the code. 
            6. Add a Disclaimer at the start of the notebook that the code is AI-generated and may require further review.
            """,
            expected_output="Just the final, optimized PySpark code with NO EXTRA TEXT ADDED TO THE CODE.",
            agent=agents[2],
            context=[stored_procedure_analysis_task, conversion_task],
        )
        
        return [
            stored_procedure_analysis_task,
            conversion_task,
            code_standards_review_task,
        ]
    
    def create_crew(self):
        """Creates the StoredProcedureToSQL crew with all agents and tasks."""
        agents = self.create_agents()
        tasks = self.create_tasks(agents)
        return Crew(
            agents=agents,
            tasks=tasks,
            process=Process.sequential,
            verbose=True,
        )
    
    def convert_stored_procedure(self, stored_procedure, workspace_id=None, lakehouse_id=None):
        """
        Orchestrates the end-to-end process of converting a SQL stored procedure to PySpark code
        with proper table reading from Microsoft Fabric Lakehouse.
        
        Args:
            stored_procedure (str): The SQL stored procedure to convert
            workspace_id (str, optional): The Microsoft Fabric workspace ID (overrides the one set at initialization)
            lakehouse_id (str, optional): The Microsoft Fabric Lakehouse ID (overrides the one set at initialization)
            
        Returns:
            dict: Results from the crew execution including the final PySpark code
        """
        workspace_id = workspace_id or self.workspace_id
        lakehouse_id = lakehouse_id or self.lakehouse_id
        
        if not workspace_id or not lakehouse_id:
            raise ValueError("workspace_id and lakehouse_id must be provided either at initialization or when calling convert_stored_procedure")
        
        inputs = {
            "stored_procedure": stored_procedure,
            "workspace_id": workspace_id,
            "lakehouse_id": lakehouse_id
        }
            
        crew = self.create_crew()
        result = crew.kickoff(inputs=inputs)
        
        return result