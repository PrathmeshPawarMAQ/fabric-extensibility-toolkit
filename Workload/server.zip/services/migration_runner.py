from utils.logger import log_migration

def run_migration(config: dict):
    log_migration(
        sp_folder_path=config["sp_folder_path"],
        views_folder_path=config["views_folder_path"],
        workspace_id=config["workspace_id"],
        lakehouse_id=config["lakehouse_id"],
        lakehouse_name=config["lakehouse_name"],
        sql_endpoint_id=config["sql_endpoint_id"],
        tables_folder_path=config["tables_folder_path"],
        functions_folder_path=config["functions_folder_path"],
        output_folder_path=config["output_folder_path"]
    )
