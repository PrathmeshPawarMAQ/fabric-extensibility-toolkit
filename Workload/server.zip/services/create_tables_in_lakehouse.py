from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM
class TableCreationConverter:
    """
    A streamlined class to convert SQL Table Creation scripts to PySpark notebooks 
    using CrewAI's multi-agent approach with optimized workflow
    """
    
    def __init__(self):
        """
        Initialize the TableCreationConverter utility
        """
        load_dotenv()
        self.llm = LLM(
            model="azure/gpt-4o", 
            temperature=0
        )
    
    def create_agents(self):
        """Create specialized agents for Table Creation script conversion"""
        schema_analyzer_converter = Agent(
            role="SQL Schema Analyzer & Converter",
            goal="Analyze SQL table schemas and convert them to PySpark StructType definitions",
            backstory="An expert who analyzes database schema structures and efficiently translates them to PySpark, with special attention to complex data types that require conversion to StringType.",
            verbose=True,
            llm=self.llm
        )
        
        lakehouse_code_specialist = Agent(
            role="Lakehouse Table Creation & Standards Specialist",
            goal="Generate optimized, standards-compliant PySpark code for Microsoft Fabric Lakehouse table creation",
            backstory="An expert in Microsoft Fabric Lakehouse operations and PySpark best practices who creates well-structured, documented code that follows all standards.",
            verbose=True,
            llm=self.llm
        )
        
        return [schema_analyzer_converter, lakehouse_code_specialist]
    
    def create_tasks(self, agents):
        """Create streamlined tasks for the Table Creation script conversion process"""
        schema_analysis_conversion_task = Task(
            description="""
                Analyze the SQL table creation script AND convert it to a PySpark StructType schema:
                
                1. Extract complete schema details:
                   - Table name
                   - All columns with names, data types, nullability, and constraints
                   - Identify any complex data types (JSON, JSONB, XML, Binary, VARBINARY, IMAGE, BLOB, CLOB, spatial types)
                
                2. Convert the schema to PySpark:
                   - Map SQL data types to PySpark types using {type_mapping}
                   - Convert ALL complex data types to StringType()
                   - Add comments above each converted complex type column
                   - Handle nullability correctly
                
                Table Creation Script:
                {table_creation_script}
            """,
            expected_output="""
                1. Brief analysis summary of the table structure
                2. Complete PySpark StructType schema definition code
                3. List of any columns that were converted from complex types to StringType
                4. Any potential conversion challenges
            """,
            agent=agents[0]
        )
        
        lakehouse_creation_task = Task(
            description="""
                Generate complete, optimized PySpark code to create the table in Microsoft Fabric Lakehouse.
                
                Lakehouse Details:
                Workspace ID: {workspace_id}
                Lakehouse ID: {lakehouse_id}
                Lakehouse Name: {lakehouse_name}
                
                Requirements:
                1. Use the converted schema from the previous task
                2. Include all necessary imports
                3. Create an empty DataFrame with the schema
                4. Write the table to the Lakehouse with proper path format
                5. Apply PySpark best practices and standards
                6. Add appropriate documentation and cell divisions
                7. Ensure complex data type conversions are properly documented
                8. Divide code into appropriate cells with "Cell------------------------" comment before each cell
                9. Add a disclaimer cell at the top of the code about AI-generated code
                10. Remove any unused imports or variables
            """,
            expected_output="Just the final, optimized PySpark code with NO EXTRA TEXT ADDED TO THE CODE.",
            agent=agents[1],
            context=[schema_analysis_conversion_task]
        )
        
        return [schema_analysis_conversion_task, lakehouse_creation_task]
    
    def create_crew(self):
        """Create the crew for sequential table creation script conversion"""
        agents = self.create_agents()
        tasks = self.create_tasks(agents)
        return Crew(
            agents=agents,
            tasks=tasks,
            process=Process.sequential,
            verbose=True
        )
    
    def convert_table_definition(self, table_creation_script, workspace_id=None, lakehouse_id=None, lakehouse_name=None):
        """
        Convert a SQL table creation script to a PySpark notebook
        
        Args:
            table_creation_script (str): SQL table creation script content
            workspace_id (str, optional): Overrides workspace ID
            type_mapping (dict, optional): Mapping of SQL data types to PySpark data types
            lakehouse_id (str, optional): Overrides lakehouse ID
            lakehouse_name (str, optional): Overrides lakehouse name
        
        Returns:
            dict: Conversion results including final PySpark code
        """
        workspace_id = workspace_id or self.workspace_id
        lakehouse_id = lakehouse_id or self.lakehouse_id
        lakehouse_name = lakehouse_name or self.lakehouse_name
        
        if not all([workspace_id, lakehouse_id, lakehouse_name]):
            raise ValueError("workspace_id, lakehouse_id, and lakehouse_name must be provided")
        type_mapping = { 
            'INT': 'IntegerType()',
            'BIGINT': 'LongType()',
            'SMALLINT': 'ShortType()',
            'TINYINT': 'ByteType()',
            'DECIMAL': 'DecimalType()',
            'FLOAT': 'FloatType()',
            'REAL': 'FloatType()',
            'DOUBLE': 'DoubleType()',
            'NUMERIC': 'DecimalType()',
            'MONEY': 'DecimalType()',
            'SMALLMONEY': 'DecimalType()',
            'BIT': 'BooleanType()',
            'CHAR': 'StringType()',
            'VARCHAR': 'StringType()',
            'TEXT': 'StringType()',
            'NCHAR': 'StringType()',
            'NVARCHAR': 'StringType()',
            'NTEXT': 'StringType()',
            'DATE': 'DateType()',
            'DATETIME': 'TimestampType()',
            'DATETIME2': 'TimestampType()',
            'DATETIMEOFFSET': 'StringType()',
            'SMALLDATETIME': 'TimestampType()',
            'TIME': 'StringType()',
            'TIMESTAMP': 'TimestampType()',
            'UNIQUEIDENTIFIER': 'StringType()',
            'XML': 'StringType()',
            'VARBINARY': 'BinaryType()',
            'BINARY': 'BinaryType()',
            'ARRAY': 'ArrayType()'
        }
          
        inputs = {
            "table_creation_script": table_creation_script,
            "workspace_id": workspace_id,
            "lakehouse_id": lakehouse_id,
            "lakehouse_name": lakehouse_name,
            "type_mapping": type_mapping
        }
        
        crew = self.create_crew()
        result = crew.kickoff(inputs=inputs)
        
        return result